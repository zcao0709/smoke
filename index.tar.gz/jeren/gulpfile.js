'user strict';

var gulp = require('gulp');   //require node_modules中的gulp包
var path = require("path");
var connect = require("gulp-connect"); //require node_modules中的gulp-connect包

var ROOT_PATH = path.resolve(__dirname); //项目根目录
var APP_PATH = path.resolve(ROOT_PATH,"app"); //应用代码目录

gulp.task("connect",function(){
    connect.server({
        root: ["."],   //使用哪个目录作为启动的根目录
        livereload:true,  //实施加载，可理解为热部署
        middleware: function(connect) {
              return [connect().use('/bower_components', connect.static('bower_components'))];  //见下文
          }
    });
});

gulp.task("default",["connect"]);  // gulp如缺省目标task则使用connect作为task
