/*
Template Name: Jeren
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
File: Back to Top JS
*/

//var animate =  require("animate.css")

jQuery("#backtotop").click(function() {
    jQuery("body,html").animate({
        scrollTop: 0
    }, 600);
});
jQuery(window).scroll(function() {
    if (jQuery(window).scrollTop() > 150) {
        jQuery("#backtotop").addClass("visible");
    } else {
        jQuery("#backtotop").removeClass("visible");
    }
});

$.fn.extend({
    animateCss: function(animationName) {
        var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        this.addClass('animated ' + animationName).one(animationEnd, function() {
            $(this).removeClass('animated ' + animationName);
        });
        return this;
    }
});

function autoPlay() {
    count++;
    $(".flex-control-nav").find("li").eq(count).find("a").click();
    // $("#bg").css("background-image", "url(images/index/main" + (count + 2) + ".jpeg)")
    if (count == 2) {
        count = -1;
    }
}

jQuery(document).ready(function() {
    count = 0
    const AUTO_PLAY_MTIME = 3000
    window.setInterval(autoPlay, AUTO_PLAY_MTIME);
    $('.inDown').addClass("hidden").viewportChecker({
        classToAdd: "visible animated fadeInDown",
        offset: 100
    });
})